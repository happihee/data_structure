#include <iostream>
#pragma once
using namespace std;

int my_len(char *str1);
char *my_cpy(char *str2, char *str1);
int my_cmp(char *str1, char *str2);
char *my_tok(char *str1, char *delemeter);
bool check_del(char ch, char *del);